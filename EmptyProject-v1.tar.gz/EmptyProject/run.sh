#!/bin/sh

sh build.sh release appletvos arm64 
sh build.sh release appletvsimulator x86_64 
sh build.sh release appletvsimulator arm64 

# BELOW WON'T WORK AS THIS IS FOR TVOS
#sh build.sh release iphoneos arm64 
#sh build.sh release iphoneos armv7 
#sh build.sh release iphonesimulator i386 
#sh build.sh release iphonesimulator x86_64 
#
