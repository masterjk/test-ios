#!/bin/sh

if [[ $# != 3 ]]; then
	echo "$0 [configuration] [sdk] [arch]"
	exit 1
fi

echo "******************************************************************************************"
echo "Testing with: configuration=$1, sdk=$2, arch=$3"

xcodebuild build \
	-workspace ./EmptyProject.xcworkspace \
	-configuration "$1" \
	-sdk $2 \
	-scheme EmptyProject \
        -arch $3 \
	-derivedDataPath derived_data CODE_SIGNING_ALLOWED=NO ENABLE_BITCODE=YES BITCODE_GENERATION_MODE=bitcode > /dev/null

if [[ $? == 0 ]]; then
	echo "SUCCESS!"
else
	echo "FAILED!"
fi
