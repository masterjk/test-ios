//
//  EmptyProjectApp.swift
//  EmptyProject
//
//  Created by Joseph Kiok on 3/25/21.
//

import SwiftUI

@main
struct EmptyProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
